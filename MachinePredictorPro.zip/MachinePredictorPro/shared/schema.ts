import { pgTable, text, serial, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (kept from original schema)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Machines table
export const machines = pgTable("machines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  location: text("location").notNull(),
  installDate: timestamp("install_date").notNull(),
  status: text("status").notNull(), // "operational", "maintenance_due", "critical", "offline"
  totalHours: integer("total_hours").notNull().default(0),
  hoursSinceService: integer("hours_since_service").notNull().default(0),
  targetServiceHours: integer("target_service_hours").notNull(),
  performance: integer("performance").notNull().default(100), // Percentage 0-100
  notes: text("notes"),
});

export const insertMachineSchema = createInsertSchema(machines).omit({
  id: true,
});

// Maintenance History table
export const maintenanceHistory = pgTable("maintenance_history", {
  id: serial("id").primaryKey(),
  machineId: integer("machine_id").notNull(),
  type: text("type").notNull(), // "preventive", "corrective", "predictive"
  description: text("description").notNull(),
  technician: text("technician").notNull(),
  date: timestamp("date").notNull(),
  duration: integer("duration").notNull(), // Duration in minutes
  partsReplaced: jsonb("parts_replaced"), // Array of parts
  cost: integer("cost"), // Cost in cents
  notes: text("notes"),
});

export const insertMaintenanceSchema = createInsertSchema(maintenanceHistory).omit({
  id: true,
});

// Maintenance Alerts table
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  machineId: integer("machine_id").notNull(),
  type: text("type").notNull(), // "critical", "warning", "info"
  title: text("title").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  resolved: boolean("resolved").notNull().default(false),
  priority: integer("priority").notNull().default(1),
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
});

// Scheduled Maintenance table
export const scheduledMaintenance = pgTable("scheduled_maintenance", {
  id: serial("id").primaryKey(),
  machineId: integer("machine_id").notNull(),
  type: text("type").notNull(), // "preventive", "regular", "urgent"
  description: text("description").notNull(),
  assignedTo: text("assigned_to").notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(),
  estimatedDuration: integer("estimated_duration").notNull(), // Duration in minutes
  completed: boolean("completed").notNull().default(false),
  completedDate: timestamp("completed_date"),
  notes: text("notes"),
});

export const insertScheduledMaintenanceSchema = createInsertSchema(scheduledMaintenance).omit({
  id: true,
  completed: true,
  completedDate: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Machine = typeof machines.$inferSelect;
export type InsertMachine = z.infer<typeof insertMachineSchema>;

export type MaintenanceHistory = typeof maintenanceHistory.$inferSelect;
export type InsertMaintenanceHistory = z.infer<typeof insertMaintenanceSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type ScheduledMaintenance = typeof scheduledMaintenance.$inferSelect;
export type InsertScheduledMaintenance = z.infer<typeof insertScheduledMaintenanceSchema>;
