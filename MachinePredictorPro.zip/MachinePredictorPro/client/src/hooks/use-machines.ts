import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Machine, InsertMachine } from "@shared/schema";

// Get all machines
export function useMachines() {
  return useQuery<Machine[]>({
    queryKey: ["/api/machines"],
  });
}

// Get a single machine by ID
export function useMachine(id: number) {
  return useQuery<Machine>({
    queryKey: ["/api/machines", id],
    enabled: !!id,
  });
}

// Create a new machine
export function useCreateMachine() {
  return useMutation({
    mutationFn: async (newMachine: InsertMachine) => {
      const res = await apiRequest("POST", "/api/machines", newMachine);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/machines"] });
    },
  });
}

// Update a machine
export function useUpdateMachine() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Machine> }) => {
      const res = await apiRequest("PUT", `/api/machines/${id}`, data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/machines"] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines", variables.id] });
    },
  });
}

// Delete a machine
export function useDeleteMachine() {
  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/machines/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/machines"] });
    },
  });
}

// Get dashboard stats
export function useDashboardStats() {
  return useQuery({
    queryKey: ["/api/dashboard/stats"],
  });
}
