import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { MaintenanceHistory, InsertMaintenanceHistory, ScheduledMaintenance, InsertScheduledMaintenance } from "@shared/schema";

// Get maintenance history
export function useMaintenanceHistory(machineId?: number) {
  const queryParams = machineId ? `?machineId=${machineId}` : "";
  
  return useQuery<MaintenanceHistory[]>({
    queryKey: ["/api/maintenance", machineId],
    queryFn: async () => {
      const res = await fetch(`/api/maintenance${queryParams}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch maintenance history");
      return res.json();
    },
  });
}

// Create a maintenance record
export function useCreateMaintenance() {
  return useMutation({
    mutationFn: async (data: InsertMaintenanceHistory) => {
      const res = await apiRequest("POST", "/api/maintenance", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/maintenance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/maintenance", variables.machineId] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines"] });
    },
  });
}

// Get scheduled maintenance
export function useScheduledMaintenance(completed?: boolean) {
  const queryParams = completed !== undefined ? `?completed=${completed}` : "";
  
  return useQuery<ScheduledMaintenance[]>({
    queryKey: ["/api/schedule", { completed }],
    queryFn: async () => {
      const res = await fetch(`/api/schedule${queryParams}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch scheduled maintenance");
      return res.json();
    },
  });
}

// Get machine scheduled maintenance
export function useMachineScheduledMaintenance(machineId: number) {
  return useQuery<ScheduledMaintenance[]>({
    queryKey: ["/api/machines", machineId, "schedule"],
    queryFn: async () => {
      const res = await fetch(`/api/machines/${machineId}/schedule`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch machine scheduled maintenance");
      return res.json();
    },
    enabled: !!machineId,
  });
}

// Create scheduled maintenance
export function useCreateScheduledMaintenance() {
  return useMutation({
    mutationFn: async (data: InsertScheduledMaintenance) => {
      const res = await apiRequest("POST", "/api/schedule", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines", variables.machineId, "schedule"] });
    },
  });
}

// Complete scheduled maintenance
export function useCompleteMaintenance() {
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/schedule/${id}/complete`, {});
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines", result.machineId, "schedule"] });
      queryClient.invalidateQueries({ queryKey: ["/api/maintenance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines"] });
    },
  });
}
