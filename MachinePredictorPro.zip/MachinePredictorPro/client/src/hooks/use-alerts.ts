import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Alert, InsertAlert } from "@shared/schema";

// Get all alerts
export function useAlerts(resolved?: boolean) {
  const queryParams = resolved !== undefined ? `?resolved=${resolved}` : "";
  
  return useQuery<Alert[]>({
    queryKey: ["/api/alerts", { resolved }],
    queryFn: async () => {
      const res = await fetch(`/api/alerts${queryParams}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch alerts");
      return res.json();
    },
  });
}

// Get machine alerts
export function useMachineAlerts(machineId: number) {
  return useQuery<Alert[]>({
    queryKey: ["/api/machines", machineId, "alerts"],
    queryFn: async () => {
      const res = await fetch(`/api/machines/${machineId}/alerts`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch machine alerts");
      return res.json();
    },
    enabled: !!machineId,
  });
}

// Create an alert
export function useCreateAlert() {
  return useMutation({
    mutationFn: async (data: InsertAlert) => {
      const res = await apiRequest("POST", "/api/alerts", data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines", variables.machineId, "alerts"] });
    },
  });
}

// Resolve an alert
export function useResolveAlert() {
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/alerts/${id}/resolve`, {});
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/machines", result.machineId, "alerts"] });
    },
  });
}
