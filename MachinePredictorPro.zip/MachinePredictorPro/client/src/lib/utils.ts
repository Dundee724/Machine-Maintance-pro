import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, formatDistanceToNow } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return format(dateObj, "MMM d, yyyy");
}

export function formatDateTime(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return format(dateObj, "MMM d, yyyy h:mm a");
}

export function formatHours(hours: number): string {
  return new Intl.NumberFormat("en-US").format(hours) + " hrs";
}

export function formatTimeAgo(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return formatDistanceToNow(dateObj, { addSuffix: true });
}

export function getStatusColor(status: string): { bg: string; text: string; indicator: string } {
  switch (status) {
    case "operational":
      return { bg: "bg-success/10", text: "text-success", indicator: "bg-success" };
    case "maintenance_due":
      return { bg: "bg-warning/10", text: "text-warning", indicator: "bg-warning" };
    case "critical":
      return { bg: "bg-error/10", text: "text-error", indicator: "bg-error" };
    case "offline":
      return { bg: "bg-neutral-400/10", text: "text-neutral-400", indicator: "bg-neutral-400" };
    default:
      return { bg: "bg-neutral-400/10", text: "text-neutral-400", indicator: "bg-neutral-400" };
  }
}

export function getPerformanceColor(performance: number): string {
  if (performance >= 90) return "bg-success";
  if (performance >= 80) return "bg-warning";
  return "bg-error";
}

export function getMaintenanceTypeColor(type: string): { bg: string; text: string } {
  switch (type) {
    case "preventive":
      return { bg: "bg-primary/10", text: "text-primary" };
    case "regular":
      return { bg: "bg-warning/10", text: "text-warning" };
    case "urgent":
      return { bg: "bg-error/10", text: "text-error" };
    default:
      return { bg: "bg-neutral-400/10", text: "text-neutral-400" };
  }
}

export function getAlertTypeColor(type: string): { bg: string; text: string; icon: string } {
  switch (type) {
    case "critical":
      return { bg: "bg-error/10", text: "text-error", icon: "bx-error" };
    case "warning":
      return { bg: "bg-warning/10", text: "text-warning", icon: "bx-timer" };
    case "info":
      return { bg: "bg-primary/10", text: "text-primary", icon: "bx-info-circle" };
    default:
      return { bg: "bg-neutral-400/10", text: "text-neutral-400", icon: "bx-info-circle" };
  }
}

export function formatStatusLabel(status: string): string {
  switch (status) {
    case "operational":
      return "Operational";
    case "maintenance_due":
      return "Maintenance Due";
    case "critical":
      return "Critical";
    case "offline":
      return "Offline";
    default:
      return status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, " ");
  }
}
