import { Machine, MaintenanceHistory } from "@shared/schema";

export function downloadCSV(csvContent: string, filename: string) {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  link.style.display = "none";
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportMachines(machines: Machine[]) {
  // Direct download from API
  window.location.href = "/api/export/machines";
}

export function exportMaintenanceHistory(history: MaintenanceHistory[]) {
  // Direct download from API
  window.location.href = "/api/export/maintenance";
}

// Client-side CSV generation (as fallback)
export function generateMachinesCSV(machines: Machine[]): string {
  const headers = ["ID", "Name", "Type", "Location", "Install Date", "Status", "Total Hours", 
                  "Hours Since Service", "Target Service Hours", "Performance", "Notes"];
  
  const rows = machines.map(machine => [
    machine.id.toString(),
    machine.name,
    machine.type,
    machine.location,
    machine.installDate.toString(),
    machine.status,
    machine.totalHours.toString(),
    machine.hoursSinceService.toString(),
    machine.targetServiceHours.toString(),
    machine.performance.toString(),
    machine.notes || ""
  ]);
  
  return [
    headers.join(","),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(","))
  ].join("\n");
}

export function generateMaintenanceHistoryCSV(history: MaintenanceHistory[]): string {
  const headers = ["ID", "Machine ID", "Type", "Description", "Technician", "Date", 
                  "Duration", "Parts Replaced", "Cost", "Notes"];
  
  const rows = history.map(record => [
    record.id.toString(),
    record.machineId.toString(),
    record.type,
    record.description,
    record.technician,
    record.date.toString(),
    record.duration.toString(),
    record.partsReplaced ? JSON.stringify(record.partsReplaced) : "",
    record.cost ? record.cost.toString() : "",
    record.notes || ""
  ]);
  
  return [
    headers.join(","),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(","))
  ].join("\n");
}
