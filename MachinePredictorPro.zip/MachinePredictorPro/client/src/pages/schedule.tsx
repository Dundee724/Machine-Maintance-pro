import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScheduledMaintenance } from "@/hooks/use-maintenance";
import { useToast } from "@/hooks/use-toast";
import { formatDate, getMaintenanceTypeColor } from "@/lib/utils";

export default function Schedule() {
  const { data: scheduledMaintenance, isLoading } = useScheduledMaintenance();
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();
  const itemsPerPage = 10;

  const handleScheduleMaintenance = () => {
    toast({
      title: "Schedule Maintenance",
      description: "Maintenance scheduling form will be implemented soon!",
    });
  };

  // Filter maintenance records
  const filteredSchedule = scheduledMaintenance 
    ? scheduledMaintenance.filter(record => {
        const matchesText = record.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            record.assignedTo.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesType = typeFilter === "all" || record.type === typeFilter;
        return matchesText && matchesType;
      })
    : [];

  // Paginate
  const paginatedSchedule = filteredSchedule.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredSchedule.length / itemsPerPage);

  const formatTime = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours + (mins > 0 ? `:${mins.toString().padStart(2, '0')}` : ':00') + ' hours';
  };

  const columns = [
    {
      key: "date",
      header: "Date",
      cell: (record: any) => (
        <div>
          <div>{formatDate(record.scheduledDate)}</div>
          <div className="text-xs text-neutral-500">{formatTime(record.scheduledDate)}</div>
        </div>
      )
    },
    {
      key: "machine",
      header: "Machine",
      cell: (record: any) => <span>ID: {record.machineId}</span> // Ideally would show machine name
    },
    {
      key: "type",
      header: "Type",
      cell: (record: any) => {
        const typeColor = getMaintenanceTypeColor(record.type);
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${typeColor.bg} ${typeColor.text} capitalize`}>
            {record.type}
          </span>
        );
      }
    },
    {
      key: "description",
      header: "Description",
      cell: (record: any) => <span>{record.description}</span>
    },
    {
      key: "assignedTo",
      header: "Assigned To",
      cell: (record: any) => <span>{record.assignedTo}</span>
    },
    {
      key: "duration",
      header: "Est. Duration",
      cell: (record: any) => <span>{formatDuration(record.estimatedDuration)}</span>
    },
    {
      key: "actions",
      header: "Actions",
      cell: (record: any) => (
        <div className="flex gap-2">
          <Button size="sm" variant="default">Complete</Button>
          <Button size="sm" variant="outline">Reschedule</Button>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 overflow-auto bg-neutral-100">
          <div className="container mx-auto px-4 py-6">
            {/* Page Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-medium text-secondary mb-4 md:mb-0">Maintenance Schedule</h1>
              <Button 
                className="flex items-center justify-center"
                onClick={handleScheduleMaintenance}
              >
                <i className='bx bx-plus mr-2'></i> Schedule Maintenance
              </Button>
            </div>
            
            {/* Schedule */}
            <Card className="shadow-sm">
              <CardHeader className="border-b border-neutral-200 py-3 px-4">
                <CardTitle className="text-secondary font-medium">Upcoming Maintenance</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <Tabs defaultValue="upcoming" className="mb-4">
                  <TabsList>
                    <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                    <TabsTrigger value="completed">Completed</TabsTrigger>
                    <TabsTrigger value="all">All</TabsTrigger>
                  </TabsList>
                </Tabs>
                
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <Input
                    placeholder="Search schedule..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full sm:w-64"
                  />
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="preventive">Preventive</SelectItem>
                      <SelectItem value="regular">Regular</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <DataTable
                  data={paginatedSchedule}
                  columns={columns}
                  isLoading={isLoading}
                  pagination={{
                    currentPage,
                    totalPages,
                    onPageChange: setCurrentPage,
                    totalItems: filteredSchedule.length,
                    itemsPerPage,
                  }}
                  emptyState={
                    <div className="p-8 text-center">
                      <i className='bx bx-calendar-check text-neutral-300 text-4xl'></i>
                      <p className="mt-2 text-sm text-neutral-500">No scheduled maintenance found</p>
                    </div>
                  }
                />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
