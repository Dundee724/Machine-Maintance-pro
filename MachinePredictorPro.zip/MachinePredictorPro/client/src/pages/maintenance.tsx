import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMaintenanceHistory } from "@/hooks/use-maintenance";
import { formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { exportMaintenanceHistory } from "@/lib/csv-export";

export default function Maintenance() {
  const { data: maintenanceHistory, isLoading } = useMaintenanceHistory();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const { toast } = useToast();
  const itemsPerPage = 10;

  const handleAddMaintenance = () => {
    toast({
      title: "Add Maintenance Record",
      description: "Maintenance record form will be implemented soon!",
    });
  };

  const handleExport = () => {
    if (maintenanceHistory) {
      exportMaintenanceHistory(maintenanceHistory);
    }
  };

  // Filter maintenance records
  const filteredHistory = maintenanceHistory 
    ? maintenanceHistory.filter(record => {
        const matchesText = record.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            record.technician.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesType = typeFilter === "all" || record.type === typeFilter;
        return matchesText && matchesType;
      })
    : [];

  // Paginate
  const paginatedHistory = filteredHistory.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredHistory.length / itemsPerPage);

  const formatCost = (cents: number | null) => {
    if (cents === null) return "N/A";
    return `$${(cents / 100).toFixed(2)}`;
  };

  const columns = [
    {
      key: "id",
      header: "ID",
      cell: (record: any) => <span>#{record.id}</span>
    },
    {
      key: "date",
      header: "Date",
      cell: (record: any) => <span>{formatDate(record.date)}</span>
    },
    {
      key: "machine",
      header: "Machine",
      cell: (record: any) => <span>ID: {record.machineId}</span> // Ideally would show machine name
    },
    {
      key: "type",
      header: "Type",
      cell: (record: any) => (
        <span className="capitalize">{record.type}</span>
      )
    },
    {
      key: "description",
      header: "Description",
      cell: (record: any) => <span>{record.description}</span>
    },
    {
      key: "technician",
      header: "Technician",
      cell: (record: any) => <span>{record.technician}</span>
    },
    {
      key: "duration",
      header: "Duration",
      cell: (record: any) => <span>{Math.floor(record.duration / 60)}h {record.duration % 60}m</span>
    },
    {
      key: "cost",
      header: "Cost",
      cell: (record: any) => <span>{formatCost(record.cost)}</span>
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 overflow-auto bg-neutral-100">
          <div className="container mx-auto px-4 py-6">
            {/* Page Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-medium text-secondary mb-4 md:mb-0">Maintenance History</h1>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  variant="outline"
                  className="flex items-center justify-center"
                  onClick={handleExport}
                >
                  <i className='bx bx-download mr-2'></i> Export CSV
                </Button>
                <Button 
                  className="flex items-center justify-center"
                  onClick={handleAddMaintenance}
                >
                  <i className='bx bx-plus mr-2'></i> Add Record
                </Button>
              </div>
            </div>
            
            {/* Maintenance History */}
            <Card className="shadow-sm">
              <CardHeader className="border-b border-neutral-200 py-3 px-4">
                <CardTitle className="text-secondary font-medium">Maintenance Records</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <Input
                    placeholder="Search records..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full sm:w-64"
                  />
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="preventive">Preventive</SelectItem>
                      <SelectItem value="corrective">Corrective</SelectItem>
                      <SelectItem value="predictive">Predictive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <DataTable
                  data={paginatedHistory}
                  columns={columns}
                  isLoading={isLoading}
                  pagination={{
                    currentPage,
                    totalPages,
                    onPageChange: setCurrentPage,
                    totalItems: filteredHistory.length,
                    itemsPerPage,
                  }}
                  emptyState={
                    <div className="p-8 text-center">
                      <i className='bx bx-file text-neutral-300 text-4xl'></i>
                      <p className="mt-2 text-sm text-neutral-500">No maintenance records found</p>
                    </div>
                  }
                />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
