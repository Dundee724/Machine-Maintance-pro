import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { EquipmentTable } from "@/components/dashboard/equipment-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function Equipment() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  const handleAddEquipment = () => {
    toast({
      title: "Add Equipment",
      description: "Equipment creation form will be implemented soon!",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 overflow-auto bg-neutral-100">
          <div className="container mx-auto px-4 py-6">
            {/* Page Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-medium text-secondary mb-4 md:mb-0">Equipment Management</h1>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative">
                  <Input 
                    type="text" 
                    placeholder="Search equipment..." 
                    className="w-full pr-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <i className='bx bx-search absolute right-3 top-2.5 text-neutral-400'></i>
                </div>
                <Button 
                  className="flex items-center justify-center"
                  onClick={handleAddEquipment}
                >
                  <i className='bx bx-plus mr-2'></i> Add Equipment
                </Button>
              </div>
            </div>
            
            {/* Equipment Table */}
            <Card className="shadow-sm">
              <CardHeader className="border-b border-neutral-200 py-3 px-4">
                <CardTitle className="text-secondary font-medium">All Equipment</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <EquipmentTable />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
