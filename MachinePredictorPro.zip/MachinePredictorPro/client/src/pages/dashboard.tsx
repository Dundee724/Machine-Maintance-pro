import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { StatusCard } from "@/components/dashboard/status-card";
import { EquipmentTable } from "@/components/dashboard/equipment-table";
import { AlertsPanel } from "@/components/dashboard/alerts-panel";
import { MaintenanceSchedule } from "@/components/dashboard/maintenance-schedule";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useDashboardStats } from "@/hooks/use-machines";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { data: stats, isLoading } = useDashboardStats();
  const { toast } = useToast();

  const handleAddEquipment = () => {
    toast({
      title: "Add Equipment",
      description: "Equipment creation form will be implemented soon!",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 overflow-auto bg-neutral-100">
          <div className="container mx-auto px-4 py-6">
            {/* Page Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-medium text-secondary mb-4 md:mb-0">Machine Maintenance Dashboard</h1>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative">
                  <Input 
                    type="text" 
                    placeholder="Search equipment..." 
                    className="w-full pr-10" 
                  />
                  <i className='bx bx-search absolute right-3 top-2.5 text-neutral-400'></i>
                </div>
                <Button 
                  className="flex items-center justify-center"
                  onClick={handleAddEquipment}
                >
                  <i className='bx bx-plus mr-2'></i> Add Equipment
                </Button>
              </div>
            </div>
            
            {/* Status Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <StatusCard
                title="Total Equipment"
                value={isLoading ? "..." : stats?.totalEquipment || 0}
                icon="bx-cog"
                iconBg="bg-primary/10"
                iconColor="text-primary"
                trend={{ value: "4", isPositive: true, label: "added this month" }}
              />
              
              <StatusCard
                title="Pending Maintenance"
                value={isLoading ? "..." : stats?.pendingMaintenance || 0}
                icon="bx-time"
                iconBg="bg-warning/10"
                iconColor="text-warning"
                trend={{ value: "3", isPositive: false, label: "due this week" }}
              />
              
              <StatusCard
                title="Critical Alerts"
                value={isLoading ? "..." : stats?.criticalAlerts || 0}
                icon="bx-error"
                iconBg="bg-error/10"
                iconColor="text-error"
                trend={{ value: "", isPositive: false, label: "Immediate attention needed" }}
              />
              
              <StatusCard
                title="Equipment Uptime"
                value={isLoading ? "..." : `${stats?.uptime.toFixed(1)}%` || "0%"}
                icon="bx-line-chart"
                iconBg="bg-success/10"
                iconColor="text-success"
                trend={{ value: "2.1%", isPositive: true, label: "from last month" }}
              />
            </div>
            
            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <EquipmentTable />
              </div>
              
              <div className="lg:col-span-1 space-y-6">
                <AlertsPanel />
                <MaintenanceSchedule />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
