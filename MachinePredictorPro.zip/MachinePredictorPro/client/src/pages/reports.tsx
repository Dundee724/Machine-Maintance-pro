import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/date-picker";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { exportMachines, exportMaintenanceHistory } from "@/lib/csv-export";
import { useMachines } from "@/hooks/use-machines";
import { useMaintenanceHistory } from "@/hooks/use-maintenance";

// Import the date-picker component
const DatePickerDemo = ({ value, onChange }: any) => {
  return (
    <div className="flex flex-col space-y-2">
      <input 
        type="date" 
        value={value?.toISOString().slice(0, 10) || ''}
        onChange={(e) => onChange(e.target.value ? new Date(e.target.value) : null)}
        className="px-3 py-2 rounded-md border border-neutral-200"
      />
    </div>
  );
};

export default function Reports() {
  const { data: machines } = useMachines();
  const { data: maintenanceHistory } = useMaintenanceHistory();
  const [reportType, setReportType] = useState("performance");
  const [dateRange, setDateRange] = useState("month");
  const [startDate, setStartDate] = useState<Date | null>(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));
  const [endDate, setEndDate] = useState<Date | null>(new Date());

  // Sample data for the charts
  const performanceData = machines ? machines.map(machine => ({
    name: machine.name,
    performance: machine.performance,
    fill: machine.performance >= 90 ? '#24a148' : 
          machine.performance >= 80 ? '#f1c21b' : '#da1e28'
  })) : [];

  const maintenanceByTypeData = [
    { name: 'Preventive', value: 8 },
    { name: 'Corrective', value: 3 },
    { name: 'Predictive', value: 2 }
  ];

  const COLORS = ['#0f62fe', '#da1e28', '#24a148', '#f1c21b'];

  const maintenanceOverTimeData = [
    { month: 'Jan', preventive: 4, corrective: 2, predictive: 1 },
    { month: 'Feb', preventive: 3, corrective: 1, predictive: 1 },
    { month: 'Mar', preventive: 5, corrective: 0, predictive: 0 },
    { month: 'Apr', preventive: 2, corrective: 3, predictive: 1 },
    { month: 'May', preventive: 4, corrective: 1, predictive: 0 },
    { month: 'Jun', preventive: 3, corrective: 2, predictive: 1 }
  ];

  const handleExportMachines = () => {
    if (machines) {
      exportMachines(machines);
    }
  };

  const handleExportMaintenance = () => {
    if (maintenanceHistory) {
      exportMaintenanceHistory(maintenanceHistory);
    }
  };

  const renderReportContent = () => {
    switch (reportType) {
      case "performance":
        return (
          <Card className="shadow-sm">
            <CardHeader className="border-b border-neutral-200 py-3 px-4">
              <CardTitle className="text-secondary font-medium">Equipment Performance</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={performanceData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} />
                    <YAxis domain={[0, 100]} label={{ value: 'Performance (%)', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="performance" fill="#0f62fe" label={{ position: 'top' }}>
                      {performanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );
      
      case "maintenance_type":
        return (
          <Card className="shadow-sm">
            <CardHeader className="border-b border-neutral-200 py-3 px-4">
              <CardTitle className="text-secondary font-medium">Maintenance by Type</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      dataKey="value"
                      data={maintenanceByTypeData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {maintenanceByTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );
      
      case "maintenance_time":
        return (
          <Card className="shadow-sm">
            <CardHeader className="border-b border-neutral-200 py-3 px-4">
              <CardTitle className="text-secondary font-medium">Maintenance Over Time</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={maintenanceOverTimeData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 10 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="preventive" stroke="#0f62fe" />
                    <Line type="monotone" dataKey="corrective" stroke="#da1e28" />
                    <Line type="monotone" dataKey="predictive" stroke="#24a148" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 overflow-auto bg-neutral-100">
          <div className="container mx-auto px-4 py-6">
            {/* Page Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-medium text-secondary mb-4 md:mb-0">Reports & Analytics</h1>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  variant="outline"
                  className="flex items-center justify-center"
                  onClick={handleExportMachines}
                >
                  <i className='bx bx-download mr-2'></i> Export Equipment
                </Button>
                <Button 
                  variant="outline"
                  className="flex items-center justify-center"
                  onClick={handleExportMaintenance}
                >
                  <i className='bx bx-download mr-2'></i> Export Maintenance
                </Button>
              </div>
            </div>
            
            {/* Report Controls */}
            <Card className="shadow-sm mb-6">
              <CardHeader className="border-b border-neutral-200 py-3 px-4">
                <CardTitle className="text-secondary font-medium">Report Settings</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-neutral-500 mb-2">Report Type</label>
                    <Select value={reportType} onValueChange={setReportType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select report type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="performance">Equipment Performance</SelectItem>
                        <SelectItem value="maintenance_type">Maintenance by Type</SelectItem>
                        <SelectItem value="maintenance_time">Maintenance Over Time</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-neutral-500 mb-2">Start Date</label>
                    <DatePickerDemo value={startDate} onChange={setStartDate} />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-neutral-500 mb-2">End Date</label>
                    <DatePickerDemo value={endDate} onChange={setEndDate} />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Report Content */}
            {renderReportContent()}
          </div>
        </main>
      </div>
    </div>
  );
}
