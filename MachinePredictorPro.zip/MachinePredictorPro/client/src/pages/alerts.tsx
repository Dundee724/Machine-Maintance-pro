import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAlerts, useResolveAlert } from "@/hooks/use-alerts";
import { getAlertTypeColor, formatTimeAgo, formatDate } from "@/lib/utils";
import { Alert } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Alerts() {
  const { data: alerts, isLoading } = useAlerts();
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const resolveAlert = useResolveAlert();
  const { toast } = useToast();
  const itemsPerPage = 10;

  const handleCreateAlert = () => {
    toast({
      title: "Create Alert",
      description: "Alert creation form will be implemented soon!",
    });
  };

  const handleResolveAlert = (id: number, title: string) => {
    resolveAlert.mutate(id, {
      onSuccess: () => {
        toast({
          title: "Alert Resolved",
          description: `Alert "${title}" has been marked as resolved.`,
        });
      },
      onError: (error) => {
        toast({
          title: "Error",
          description: "Failed to resolve the alert. Please try again.",
          variant: "destructive",
        });
      },
    });
  };

  // Filter alerts
  const filteredAlerts = alerts 
    ? alerts.filter(alert => {
        const matchesText = alert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           alert.description.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesType = typeFilter === "all" || alert.type === typeFilter;
        return matchesText && matchesType;
      })
    : [];

  // Paginate
  const paginatedAlerts = filteredAlerts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredAlerts.length / itemsPerPage);

  const columns = [
    {
      key: "severity",
      header: "Severity",
      cell: (alert: Alert) => {
        const alertColor = getAlertTypeColor(alert.type);
        return (
          <div className="flex items-center">
            <div className={`rounded-full p-2 ${alertColor.bg} mr-2`}>
              <i className={`bx ${alertColor.icon} ${alertColor.text}`}></i>
            </div>
            <span className={`capitalize ${alertColor.text}`}>{alert.type}</span>
          </div>
        );
      }
    },
    {
      key: "title",
      header: "Title",
      cell: (alert: Alert) => <span className="font-medium">{alert.title}</span>
    },
    {
      key: "description",
      header: "Description",
      cell: (alert: Alert) => <span>{alert.description}</span>,
      className: "max-w-md"
    },
    {
      key: "machine",
      header: "Machine ID",
      cell: (alert: Alert) => <span>{alert.machineId}</span>
    },
    {
      key: "created",
      header: "Created",
      cell: (alert: Alert) => (
        <div>
          <div>{formatDate(alert.createdAt)}</div>
          <div className="text-xs text-neutral-500">{formatTimeAgo(alert.createdAt)}</div>
        </div>
      )
    },
    {
      key: "status",
      header: "Status",
      cell: (alert: Alert) => (
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          alert.resolved 
            ? "bg-success/10 text-success" 
            : "bg-error/10 text-error"
        }`}>
          {alert.resolved ? "Resolved" : "Active"}
        </span>
      )
    },
    {
      key: "actions",
      header: "Actions",
      cell: (alert: Alert) => (
        <div className="flex gap-2">
          {!alert.resolved && (
            <Button 
              size="sm" 
              variant="default"
              onClick={() => handleResolveAlert(alert.id, alert.title)}
              disabled={resolveAlert.isPending}
            >
              Resolve
            </Button>
          )}
          <Button size="sm" variant="outline">Details</Button>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 overflow-auto bg-neutral-100">
          <div className="container mx-auto px-4 py-6">
            {/* Page Header */}
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-medium text-secondary mb-4 md:mb-0">Maintenance Alerts</h1>
              <Button 
                className="flex items-center justify-center"
                onClick={handleCreateAlert}
              >
                <i className='bx bx-plus mr-2'></i> Create Alert
              </Button>
            </div>
            
            {/* Alert Filters */}
            <Card className="shadow-sm mb-6">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-neutral-500 mb-2">Search Alerts</label>
                    <Input
                      placeholder="Search by title or description..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-neutral-500 mb-2">Alert Type</label>
                    <Select value={typeFilter} onValueChange={setTypeFilter}>
                      <SelectTrigger className="w-full sm:w-40">
                        <SelectValue placeholder="All Types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="warning">Warning</SelectItem>
                        <SelectItem value="info">Info</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-neutral-500 mb-2">Status</label>
                    <Select defaultValue="active">
                      <SelectTrigger className="w-full sm:w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Alerts Table */}
            <Card className="shadow-sm">
              <CardHeader className="border-b border-neutral-200 py-3 px-4">
                <CardTitle className="text-secondary font-medium">All Alerts</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <DataTable
                  data={paginatedAlerts}
                  columns={columns}
                  isLoading={isLoading || resolveAlert.isPending}
                  pagination={{
                    currentPage,
                    totalPages,
                    onPageChange: setCurrentPage,
                    totalItems: filteredAlerts.length,
                    itemsPerPage,
                  }}
                  emptyState={
                    <div className="p-8 text-center">
                      <i className='bx bx-bell-off text-neutral-300 text-4xl'></i>
                      <p className="mt-2 text-sm text-neutral-500">No alerts found</p>
                    </div>
                  }
                />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
