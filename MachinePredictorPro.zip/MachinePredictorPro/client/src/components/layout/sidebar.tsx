import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();
  const [isMobileExpanded, setIsMobileExpanded] = useState(false);

  const isActive = (path: string) => location === path;

  const navItems = [
    { path: "/", icon: "bxs-dashboard", label: "Dashboard" },
    { path: "/equipment", icon: "bx-cog", label: "Equipment" },
    { path: "/maintenance", icon: "bx-wrench", label: "Maintenance" },
    { path: "/schedule", icon: "bx-calendar", label: "Schedule" },
    { path: "/reports", icon: "bx-line-chart", label: "Reports" },
    { path: "/alerts", icon: "bx-bell", label: "Alerts" },
  ];

  return (
    <aside className="w-16 md:w-64 bg-secondary text-white">
      <div className="h-full flex flex-col">
        <div className="md:hidden p-4 flex justify-center">
          <button 
            onClick={() => setIsMobileExpanded(!isMobileExpanded)}
            className="text-white focus:outline-none"
          >
            <i className={`bx ${isMobileExpanded ? 'bx-x' : 'bx-menu'} text-xl`}></i>
          </button>
        </div>

        <nav className={`flex-1 py-4 ${isMobileExpanded ? 'block' : 'hidden md:block'}`}>
          <ul>
            {navItems.map((item) => (
              <li key={item.path} className="mb-1">
                <Link href={item.path}>
                  <a 
                    className={cn(
                      "flex items-center px-4 py-3",
                      isActive(item.path)
                        ? "text-white bg-primary bg-opacity-20 border-l-4 border-primary"
                        : "text-neutral-300 hover:bg-primary hover:bg-opacity-10 hover:text-white"
                    )}
                    onClick={() => setIsMobileExpanded(false)}
                  >
                    <i className={cn('bx', item.icon, 'text-xl md:mr-3')}></i>
                    <span className="hidden md:inline">{item.label}</span>
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className={`p-4 border-t border-neutral-500 ${isMobileExpanded ? 'block' : 'hidden md:block'}`}>
          <a href="#" className="flex items-center text-neutral-300 hover:text-white">
            <i className='bx bx-help-circle text-xl md:mr-3'></i>
            <span className="hidden md:inline text-sm">Help & Support</span>
          </a>
        </div>
      </div>
    </aside>
  );
}
