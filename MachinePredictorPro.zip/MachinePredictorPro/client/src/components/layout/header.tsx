import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

export function Header() {
  const { toast } = useToast();

  const handleNotificationClick = () => {
    toast({
      title: "Notifications",
      description: "Notification feature will be implemented soon!",
    });
  };

  return (
    <header className="bg-white border-b border-neutral-200 shadow-sm">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
            <path d="M21.7 18.6L17.4 14.3C18.5 12.8 19.1 11 19.1 9C19.1 4.6 15.5 1 11.1 1C6.7 1 3.1 4.6 3.1 9C3.1 13.4 6.7 17 11.1 17C13.1 17 14.9 16.4 16.4 15.3L20.7 19.6C21.1 20 21.7 20 22.1 19.6C22.5 19.2 22.1 19 21.7 18.6ZM11.1 15C7.8 15 5.1 12.3 5.1 9C5.1 5.7 7.8 3 11.1 3C14.4 3 17.1 5.7 17.1 9C17.1 12.3 14.4 15 11.1 15Z"></path>
          </svg>
          <h1 className="ml-2 text-xl font-medium text-secondary">MaintainX</h1>
        </div>
        <div className="flex items-center">
          <div className="mr-4 relative">
            <Button 
              variant="ghost" 
              size="icon" 
              className="relative text-neutral-500 hover:text-primary"
              onClick={handleNotificationClick}
            >
              <i className='bx bx-bell text-xl'></i>
              <span className="absolute top-0 right-0 w-2 h-2 bg-primary rounded-full"></span>
            </Button>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <div className="flex items-center cursor-pointer">
                <span className="mr-2 text-sm font-medium text-neutral-500">Alex Morgan</span>
                <div className="w-8 h-8 rounded-full bg-neutral-300 flex items-center justify-center text-neutral-500">
                  <span className="text-sm font-medium">AM</span>
                </div>
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
