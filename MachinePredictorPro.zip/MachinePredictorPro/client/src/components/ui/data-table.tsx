import React from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface DataTableProps<T> {
  data: T[];
  columns: {
    key: string;
    header: string;
    cell: (item: T) => React.ReactNode;
    className?: string;
  }[];
  isLoading?: boolean;
  emptyState?: React.ReactNode;
  rowClassName?: (item: T) => string;
  pagination?: {
    currentPage: number;
    totalPages: number;
    onPageChange: (page: number) => void;
    totalItems?: number;
    itemsPerPage?: number;
  };
}

export function DataTable<T>({
  data,
  columns,
  isLoading,
  emptyState,
  rowClassName,
  pagination,
}: DataTableProps<T>) {
  if (isLoading) {
    return (
      <div className="w-full p-8 flex justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (data.length === 0 && emptyState) {
    return emptyState;
  }

  return (
    <div className="w-full">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-neutral-100">
              {columns.map((column) => (
                <TableHead 
                  key={column.key} 
                  className={cn("px-4 py-3 text-left text-neutral-500 text-sm font-medium", column.className)}
                >
                  {column.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item, index) => (
              <TableRow 
                key={index} 
                className={cn("border-b border-neutral-200", rowClassName && rowClassName(item))}
              >
                {columns.map((column) => (
                  <TableCell 
                    key={`${index}-${column.key}`} 
                    className={cn("px-4 py-3", column.className)}
                  >
                    {column.cell(item)}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {pagination && (
        <div className="px-4 py-3 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between">
          {pagination.totalItems && (
            <span className="text-sm text-neutral-500 mb-3 sm:mb-0">
              Showing {Math.min((pagination.currentPage - 1) * (pagination.itemsPerPage || 10) + 1, pagination.totalItems)} to {Math.min(pagination.currentPage * (pagination.itemsPerPage || 10), pagination.totalItems)} of {pagination.totalItems} items
            </span>
          )}
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => pagination.onPageChange(pagination.currentPage - 1)}
              disabled={pagination.currentPage === 1}
              className="px-3 py-1 h-auto"
            >
              Previous
            </Button>
            
            {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={page === pagination.currentPage ? "default" : "outline"}
                size="sm"
                onClick={() => pagination.onPageChange(page)}
                className="px-3 py-1 h-auto"
              >
                {page}
              </Button>
            ))}
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => pagination.onPageChange(pagination.currentPage + 1)}
              disabled={pagination.currentPage === pagination.totalPages}
              className="px-3 py-1 h-auto"
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
