import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const getStatusConfig = () => {
    switch (status) {
      case "operational":
        return { 
          bg: "bg-success/10", 
          text: "text-success", 
          indicator: "bg-success",
          label: "Operational" 
        };
      case "maintenance_due":
        return { 
          bg: "bg-warning/10", 
          text: "text-warning", 
          indicator: "bg-warning",
          label: "Maintenance Due" 
        };
      case "critical":
        return { 
          bg: "bg-error/10", 
          text: "text-error", 
          indicator: "bg-error",
          label: "Critical" 
        };
      case "offline":
        return { 
          bg: "bg-neutral-400/10", 
          text: "text-neutral-400", 
          indicator: "bg-neutral-400",
          label: "Offline" 
        };
      default:
        return { 
          bg: "bg-neutral-400/10", 
          text: "text-neutral-400", 
          indicator: "bg-neutral-400",
          label: status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, " ")
        };
    }
  };

  const config = getStatusConfig();

  return (
    <span 
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        config.bg,
        config.text,
        className
      )}
    >
      <span className="w-2 h-2 rounded-full mr-1.5" style={{ backgroundColor: `var(--${config.indicator.split('-')[1]})` }}></span>
      {config.label}
    </span>
  );
}
