import { cn } from "@/lib/utils";

interface PerformanceBarProps {
  value: number;
  className?: string;
  showLabel?: boolean;
}

export function PerformanceBar({ value, className, showLabel = true }: PerformanceBarProps) {
  const getColorClass = () => {
    if (value >= 90) return "bg-success";
    if (value >= 80) return "bg-warning";
    return "bg-error";
  };

  return (
    <div className={cn("w-full", className)}>
      {showLabel && (
        <div className="mb-1 flex justify-between items-center">
          <span className="text-sm">{value}%</span>
        </div>
      )}
      <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
        <div 
          className={cn("h-full rounded-full", getColorClass())} 
          style={{ width: `${value}%` }}
        ></div>
      </div>
    </div>
  );
}
