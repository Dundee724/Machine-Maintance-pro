import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatusCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconBg: string;
  iconColor: string;
  trend?: {
    value: string;
    isPositive: boolean;
    label: string;
  };
}

export function StatusCard({ title, value, icon, iconBg, iconColor, trend }: StatusCardProps) {
  return (
    <Card className="border border-neutral-200">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-sm text-neutral-500">{title}</span>
            <h2 className="text-2xl font-medium">{value}</h2>
          </div>
          <div className={cn("p-2 rounded-md", iconBg)}>
            <i className={cn("bx", icon, "text-xl", iconColor)}></i>
          </div>
        </div>
        {trend && (
          <div className="mt-4 text-sm">
            <span 
              className={cn(
                "flex items-center", 
                trend.isPositive ? "text-success" : "text-error"
              )}
            >
              <i className={cn(
                "bx", 
                trend.isPositive ? "bx-up-arrow-alt" : "bx-down-arrow-alt"
              )}></i>
              {trend.value} {trend.label}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
