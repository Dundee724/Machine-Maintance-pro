import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useAlerts } from "@/hooks/use-alerts";
import { getAlertTypeColor, formatTimeAgo } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export function AlertsPanel() {
  const { data: alerts, isLoading } = useAlerts(false);
  const { toast } = useToast();

  const handleSchedule = (alertId: number, title: string) => {
    toast({
      title: "Maintenance Scheduled",
      description: `Scheduled maintenance for ${title}`,
    });
  };

  return (
    <Card className="shadow-sm h-full flex flex-col">
      <CardHeader className="border-b border-neutral-200 py-3 px-4 flex flex-row justify-between items-center">
        <CardTitle className="text-secondary font-medium">Maintenance Alerts</CardTitle>
        <Link href="/alerts">
          <Button variant="link" className="p-0 h-auto text-primary text-sm">
            View All
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="p-0 flex-grow overflow-auto">
        {isLoading ? (
          <div className="p-4 text-center">
            <div className="animate-spin h-6 w-6 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-2 text-sm text-neutral-500">Loading alerts...</p>
          </div>
        ) : alerts && alerts.length > 0 ? (
          <div className="p-2">
            {alerts.slice(0, 3).map((alert) => {
              const alertColor = getAlertTypeColor(alert.type);
              
              return (
                <div key={alert.id} className="p-3 border-b border-neutral-200 flex items-start last:border-b-0">
                  <div className={`rounded-full p-2 ${alertColor.bg} mr-3`}>
                    <i className={`bx ${alertColor.icon} ${alertColor.text}`}></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">{alert.title}</h3>
                    <p className="text-xs text-neutral-500 mt-1">{alert.description}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <Button 
                        size="sm" 
                        className="px-2 py-1 h-auto text-xs"
                        onClick={() => handleSchedule(alert.id, alert.title)}
                      >
                        Schedule
                      </Button>
                      <span className={`text-xs ${alertColor.text}`}>
                        {formatTimeAgo(alert.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center">
            <i className='bx bx-check-circle text-success text-4xl'></i>
            <p className="mt-2 text-sm text-neutral-500">No active alerts</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-neutral-200 p-4">
        <Button className="w-full" variant="outline">
          Create Alert
        </Button>
      </CardFooter>
    </Card>
  );
}
