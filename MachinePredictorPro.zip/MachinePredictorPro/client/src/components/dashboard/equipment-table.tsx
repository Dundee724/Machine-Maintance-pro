import { useState } from "react";
import { DataTable } from "@/components/ui/data-table";
import { StatusBadge } from "@/components/ui/status-badge";
import { PerformanceBar } from "@/components/ui/performance-bar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDate, formatHours } from "@/lib/utils";
import { useMachines } from "@/hooks/use-machines";
import { exportMachines } from "@/lib/csv-export";
import { Machine } from "@shared/schema";

export function EquipmentTable() {
  const { data: machines, isLoading } = useMachines();
  const [currentPage, setCurrentPage] = useState(1);
  const [filterText, setFilterText] = useState("");
  const [locationFilter, setLocationFilter] = useState("all");
  const itemsPerPage = 5;

  // Filter and sort the machines
  const filteredMachines = machines ? machines.filter(machine => {
    const matchesText = machine.name.toLowerCase().includes(filterText.toLowerCase()) ||
                        machine.location.toLowerCase().includes(filterText.toLowerCase());
    const matchesLocation = locationFilter === "all" || machine.location === locationFilter;
    return matchesText && matchesLocation;
  }) : [];

  // Get unique locations for filter dropdown
  const locations = machines 
    ? Array.from(new Set(machines.map(m => m.location)))
    : [];

  // Get paginated results
  const paginatedMachines = filteredMachines.slice(
    (currentPage - 1) * itemsPerPage, 
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredMachines.length / itemsPerPage);

  const handleExport = () => {
    if (machines) {
      exportMachines(machines);
    }
  };

  const columns = [
    {
      key: "name",
      header: "Equipment",
      cell: (machine: Machine) => (
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center mr-3">
            <i className='bx bx-chip text-primary'></i>
          </div>
          <div>
            <div className="font-medium">{machine.name}</div>
            <div className="text-xs text-neutral-500">{machine.location}</div>
          </div>
        </div>
      )
    },
    {
      key: "status",
      header: "Status",
      cell: (machine: Machine) => <StatusBadge status={machine.status} />
    },
    {
      key: "hours",
      header: "Hours",
      cell: (machine: Machine) => (
        <div>
          <div>{formatHours(machine.totalHours)}</div>
          <div className={`text-xs ${
            (machine.hoursSinceService / machine.targetServiceHours) > 0.9 
              ? "text-error" 
              : (machine.hoursSinceService / machine.targetServiceHours) > 0.7 
                ? "text-warning" 
                : "text-success"
          }`}>
            {formatHours(machine.hoursSinceService)} since last service
          </div>
        </div>
      )
    },
    {
      key: "lastMaintenance",
      header: "Last Maintenance",
      cell: (machine: Machine) => {
        // This would be replaced with actual last maintenance date from history
        return (
          <div>
            <div>{formatDate(machine.installDate)}</div>
            <div className="text-xs text-neutral-500">Regular service</div>
          </div>
        );
      }
    },
    {
      key: "performance",
      header: "Performance",
      cell: (machine: Machine) => (
        <PerformanceBar value={machine.performance} />
      )
    },
    {
      key: "actions",
      header: "Actions",
      cell: (machine: Machine) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0 text-primary hover:text-primary/80">
              <i className='bx bx-dots-vertical-rounded text-xl'></i>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>View Details</DropdownMenuItem>
            <DropdownMenuItem>Edit Equipment</DropdownMenuItem>
            <DropdownMenuItem>Schedule Maintenance</DropdownMenuItem>
            <DropdownMenuItem>View History</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )
    }
  ];

  return (
    <Card className="shadow-sm">
      <CardHeader className="border-b border-neutral-200 py-3 px-4 flex flex-row justify-between items-center">
        <CardTitle className="text-secondary font-medium">Equipment Status</CardTitle>
        <div className="flex items-center gap-2">
          <Select value={locationFilter} onValueChange={setLocationFilter}>
            <SelectTrigger className="text-sm border border-neutral-200 rounded h-8 w-40">
              <SelectValue placeholder="All Equipment" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Equipment</SelectItem>
              {locations.map(location => (
                <SelectItem key={location} value={location}>{location}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="ghost" size="icon" onClick={handleExport}>
            <i className='bx bx-download'></i>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="p-4">
          <Input
            placeholder="Search equipment..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            className="w-full mb-4"
          />
        </div>
        <DataTable
          data={paginatedMachines}
          columns={columns}
          isLoading={isLoading}
          pagination={{
            currentPage,
            totalPages,
            onPageChange: setCurrentPage,
            totalItems: filteredMachines.length,
            itemsPerPage,
          }}
        />
      </CardContent>
    </Card>
  );
}
