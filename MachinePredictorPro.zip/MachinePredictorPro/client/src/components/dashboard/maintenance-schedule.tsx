import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useScheduledMaintenance } from "@/hooks/use-maintenance";
import { getMaintenanceTypeColor, formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export function MaintenanceSchedule() {
  const { data: schedule, isLoading } = useScheduledMaintenance(false);
  const { toast } = useToast();

  const handleScheduleClick = () => {
    toast({
      title: "Schedule Maintenance",
      description: "Schedule maintenance feature will be implemented soon!",
    });
  };

  const formatTime = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `Est. ${hours}${mins > 0 ? `.${mins}` : ''} hours`;
  };

  return (
    <Card className="shadow-sm h-full flex flex-col">
      <CardHeader className="border-b border-neutral-200 py-3 px-4 flex flex-row justify-between items-center">
        <CardTitle className="text-secondary font-medium">Upcoming Maintenance</CardTitle>
        <Button variant="ghost" size="sm" className="p-1 h-auto">
          <i className='bx bx-calendar text-neutral-500 hover:text-primary'></i>
        </Button>
      </CardHeader>
      <CardContent className="p-0 flex-grow overflow-auto">
        {isLoading ? (
          <div className="p-4 text-center">
            <div className="animate-spin h-6 w-6 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-2 text-sm text-neutral-500">Loading schedule...</p>
          </div>
        ) : schedule && schedule.length > 0 ? (
          <div className="p-2">
            {schedule.slice(0, 3).map((item) => {
              const typeColor = getMaintenanceTypeColor(item.type);
              
              return (
                <div key={item.id} className="p-3 border-b border-neutral-200 last:border-b-0">
                  <div className="flex justify-between">
                    <h3 className="font-medium text-sm">{item.description}</h3>
                    <span className={`text-xs ${typeColor.bg} ${typeColor.text} px-2 py-1 rounded-full`}>
                      {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center text-xs text-neutral-500">
                    <i className='bx bx-calendar mr-1'></i>
                    <span>{formatDate(item.scheduledDate)}</span>
                    <span className="mx-2">•</span>
                    <i className='bx bx-time mr-1'></i>
                    <span>{formatTime(item.scheduledDate)}</span>
                  </div>
                  <div className="mt-2 flex items-center text-xs text-neutral-500">
                    <i className='bx bx-user mr-1'></i>
                    <span>{item.assignedTo}</span>
                    <span className="mx-2">•</span>
                    <span>{formatDuration(item.estimatedDuration)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center">
            <i className='bx bx-calendar-check text-primary text-4xl'></i>
            <p className="mt-2 text-sm text-neutral-500">No upcoming maintenance</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-neutral-200 p-4">
        <Button 
          className="w-full" 
          variant="outline"
          onClick={handleScheduleClick}
        >
          Schedule Maintenance
        </Button>
      </CardFooter>
    </Card>
  );
}
