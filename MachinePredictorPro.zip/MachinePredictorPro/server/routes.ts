import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMachineSchema, insertMaintenanceSchema, insertAlertSchema, insertScheduledMaintenanceSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard stats
  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Machine routes
  app.get("/api/machines", async (req: Request, res: Response) => {
    try {
      const machines = await storage.getMachines();
      res.json(machines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch machines" });
    }
  });

  app.get("/api/machines/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const machine = await storage.getMachine(id);
      
      if (!machine) {
        return res.status(404).json({ message: "Machine not found" });
      }
      
      res.json(machine);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch machine" });
    }
  });

  app.post("/api/machines", async (req: Request, res: Response) => {
    try {
      const result = insertMachineSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid machine data", 
          errors: fromZodError(result.error).message
        });
      }
      
      const machine = await storage.createMachine(result.data);
      res.status(201).json(machine);
    } catch (error) {
      res.status(500).json({ message: "Failed to create machine" });
    }
  });

  app.put("/api/machines/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const result = insertMachineSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid machine data",
          errors: fromZodError(result.error).message
        });
      }
      
      const updatedMachine = await storage.updateMachine(id, result.data);
      
      if (!updatedMachine) {
        return res.status(404).json({ message: "Machine not found" });
      }
      
      res.json(updatedMachine);
    } catch (error) {
      res.status(500).json({ message: "Failed to update machine" });
    }
  });

  app.delete("/api/machines/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteMachine(id);
      
      if (!success) {
        return res.status(404).json({ message: "Machine not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete machine" });
    }
  });

  // Maintenance history routes
  app.get("/api/maintenance", async (req: Request, res: Response) => {
    try {
      const machineId = req.query.machineId ? parseInt(req.query.machineId as string) : undefined;
      const history = await storage.getMaintenanceHistory(machineId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch maintenance history" });
    }
  });

  app.post("/api/maintenance", async (req: Request, res: Response) => {
    try {
      const result = insertMaintenanceSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid maintenance data",
          errors: fromZodError(result.error).message
        });
      }
      
      const maintenance = await storage.createMaintenanceRecord(result.data);
      res.status(201).json(maintenance);
    } catch (error) {
      res.status(500).json({ message: "Failed to create maintenance record" });
    }
  });

  // Alert routes
  app.get("/api/alerts", async (req: Request, res: Response) => {
    try {
      const resolved = req.query.resolved === "true" ? true : 
                     req.query.resolved === "false" ? false : 
                     undefined;
      const alerts = await storage.getAlerts(resolved);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.get("/api/machines/:id/alerts", async (req: Request, res: Response) => {
    try {
      const machineId = parseInt(req.params.id);
      const alerts = await storage.getAlertsByMachine(machineId);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch machine alerts" });
    }
  });

  app.post("/api/alerts", async (req: Request, res: Response) => {
    try {
      const result = insertAlertSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid alert data",
          errors: fromZodError(result.error).message
        });
      }
      
      const alert = await storage.createAlert(result.data);
      res.status(201).json(alert);
    } catch (error) {
      res.status(500).json({ message: "Failed to create alert" });
    }
  });

  app.patch("/api/alerts/:id/resolve", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const resolvedAlert = await storage.resolveAlert(id);
      
      if (!resolvedAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      res.json(resolvedAlert);
    } catch (error) {
      res.status(500).json({ message: "Failed to resolve alert" });
    }
  });

  // Scheduled maintenance routes
  app.get("/api/schedule", async (req: Request, res: Response) => {
    try {
      const completed = req.query.completed === "true" ? true : 
                      req.query.completed === "false" ? false : 
                      undefined;
      const scheduledMaintenance = await storage.getScheduledMaintenance(completed);
      res.json(scheduledMaintenance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scheduled maintenance" });
    }
  });

  app.get("/api/machines/:id/schedule", async (req: Request, res: Response) => {
    try {
      const machineId = parseInt(req.params.id);
      const scheduledMaintenance = await storage.getScheduledMaintenanceByMachine(machineId);
      res.json(scheduledMaintenance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch machine scheduled maintenance" });
    }
  });

  app.post("/api/schedule", async (req: Request, res: Response) => {
    try {
      const result = insertScheduledMaintenanceSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid scheduled maintenance data",
          errors: fromZodError(result.error).message
        });
      }
      
      const scheduledMaintenance = await storage.createScheduledMaintenance(result.data);
      res.status(201).json(scheduledMaintenance);
    } catch (error) {
      res.status(500).json({ message: "Failed to create scheduled maintenance" });
    }
  });

  app.patch("/api/schedule/:id/complete", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const completedMaintenance = await storage.completeMaintenance(id);
      
      if (!completedMaintenance) {
        return res.status(404).json({ message: "Scheduled maintenance not found" });
      }
      
      res.json(completedMaintenance);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete scheduled maintenance" });
    }
  });

  // Export data
  app.get("/api/export/machines", async (req: Request, res: Response) => {
    try {
      const machines = await storage.getMachines();
      
      // Convert to CSV format
      const headers = "ID,Name,Type,Location,Install Date,Status,Total Hours,Hours Since Service,Target Service Hours,Performance,Notes\n";
      const rows = machines.map(m => 
        `${m.id},"${m.name}","${m.type}","${m.location}","${m.installDate.toISOString()}","${m.status}",${m.totalHours},${m.hoursSinceService},${m.targetServiceHours},${m.performance},"${m.notes || ''}"`
      ).join("\n");
      
      const csv = headers + rows;
      
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=machines.csv");
      res.status(200).send(csv);
    } catch (error) {
      res.status(500).json({ message: "Failed to export machines data" });
    }
  });

  app.get("/api/export/maintenance", async (req: Request, res: Response) => {
    try {
      const history = await storage.getMaintenanceHistory();
      
      // Convert to CSV format
      const headers = "ID,Machine ID,Type,Description,Technician,Date,Duration,Parts Replaced,Cost,Notes\n";
      const rows = history.map(h => 
        `${h.id},${h.machineId},"${h.type}","${h.description}","${h.technician}","${h.date.toISOString()}",${h.duration},"${h.partsReplaced ? JSON.stringify(h.partsReplaced) : ''}",${h.cost || ''},"${h.notes || ''}"`
      ).join("\n");
      
      const csv = headers + rows;
      
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=maintenance_history.csv");
      res.status(200).send(csv);
    } catch (error) {
      res.status(500).json({ message: "Failed to export maintenance data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
