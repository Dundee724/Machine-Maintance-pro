import { 
  users, type User, type InsertUser,
  machines, type Machine, type InsertMachine,
  maintenanceHistory, type MaintenanceHistory, type InsertMaintenanceHistory,
  alerts, type Alert, type InsertAlert,
  scheduledMaintenance, type ScheduledMaintenance, type InsertScheduledMaintenance
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User methods (existing)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Machine methods
  getMachines(): Promise<Machine[]>;
  getMachine(id: number): Promise<Machine | undefined>;
  createMachine(machine: InsertMachine): Promise<Machine>;
  updateMachine(id: number, machine: Partial<Machine>): Promise<Machine | undefined>;
  deleteMachine(id: number): Promise<boolean>;
  
  // Maintenance history methods
  getMaintenanceHistory(machineId?: number): Promise<MaintenanceHistory[]>;
  createMaintenanceRecord(record: InsertMaintenanceHistory): Promise<MaintenanceHistory>;
  
  // Alert methods
  getAlerts(resolved?: boolean): Promise<Alert[]>;
  getAlertsByMachine(machineId: number): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  resolveAlert(id: number): Promise<Alert | undefined>;
  
  // Scheduled maintenance methods
  getScheduledMaintenance(completed?: boolean): Promise<ScheduledMaintenance[]>;
  getScheduledMaintenanceByMachine(machineId: number): Promise<ScheduledMaintenance[]>;
  createScheduledMaintenance(maintenance: InsertScheduledMaintenance): Promise<ScheduledMaintenance>;
  completeMaintenance(id: number): Promise<ScheduledMaintenance | undefined>;
  
  // Dashboard stats
  getDashboardStats(): Promise<{
    totalEquipment: number;
    pendingMaintenance: number;
    criticalAlerts: number;
    uptime: number;
  }>;
}

// In-memory implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private machines: Map<number, Machine>;
  private maintenanceHistory: Map<number, MaintenanceHistory>;
  private alerts: Map<number, Alert>;
  private scheduledMaintenance: Map<number, ScheduledMaintenance>;
  
  private currentUserId: number = 1;
  private currentMachineId: number = 1;
  private currentMaintenanceId: number = 1;
  private currentAlertId: number = 1;
  private currentScheduleId: number = 1;

  constructor() {
    this.users = new Map();
    this.machines = new Map();
    this.maintenanceHistory = new Map();
    this.alerts = new Map();
    this.scheduledMaintenance = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User methods (existing)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Machine methods
  async getMachines(): Promise<Machine[]> {
    return Array.from(this.machines.values());
  }

  async getMachine(id: number): Promise<Machine | undefined> {
    return this.machines.get(id);
  }

  async createMachine(insertMachine: InsertMachine): Promise<Machine> {
    const id = this.currentMachineId++;
    const machine: Machine = { ...insertMachine, id };
    this.machines.set(id, machine);
    return machine;
  }

  async updateMachine(id: number, machineUpdate: Partial<Machine>): Promise<Machine | undefined> {
    const existingMachine = this.machines.get(id);
    if (!existingMachine) return undefined;
    
    const updatedMachine = { ...existingMachine, ...machineUpdate };
    this.machines.set(id, updatedMachine);
    return updatedMachine;
  }

  async deleteMachine(id: number): Promise<boolean> {
    return this.machines.delete(id);
  }

  // Maintenance history methods
  async getMaintenanceHistory(machineId?: number): Promise<MaintenanceHistory[]> {
    const history = Array.from(this.maintenanceHistory.values());
    return machineId 
      ? history.filter(record => record.machineId === machineId)
      : history;
  }

  async createMaintenanceRecord(record: InsertMaintenanceHistory): Promise<MaintenanceHistory> {
    const id = this.currentMaintenanceId++;
    const maintenanceRecord: MaintenanceHistory = { ...record, id };
    this.maintenanceHistory.set(id, maintenanceRecord);
    
    // Reset hours since service for the machine
    const machine = this.machines.get(record.machineId);
    if (machine) {
      this.machines.set(record.machineId, { ...machine, hoursSinceService: 0 });
    }
    
    return maintenanceRecord;
  }

  // Alert methods
  async getAlerts(resolved?: boolean): Promise<Alert[]> {
    const allAlerts = Array.from(this.alerts.values());
    return resolved !== undefined 
      ? allAlerts.filter(alert => alert.resolved === resolved)
      : allAlerts;
  }

  async getAlertsByMachine(machineId: number): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.machineId === machineId);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentAlertId++;
    const alert: Alert = { ...insertAlert, id };
    this.alerts.set(id, alert);
    return alert;
  }

  async resolveAlert(id: number): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, resolved: true };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }

  // Scheduled maintenance methods
  async getScheduledMaintenance(completed?: boolean): Promise<ScheduledMaintenance[]> {
    const allScheduled = Array.from(this.scheduledMaintenance.values());
    return completed !== undefined 
      ? allScheduled.filter(m => m.completed === completed)
      : allScheduled;
  }

  async getScheduledMaintenanceByMachine(machineId: number): Promise<ScheduledMaintenance[]> {
    return Array.from(this.scheduledMaintenance.values())
      .filter(m => m.machineId === machineId);
  }

  async createScheduledMaintenance(insertMaintenance: InsertScheduledMaintenance): Promise<ScheduledMaintenance> {
    const id = this.currentScheduleId++;
    const maintenance: ScheduledMaintenance = { 
      ...insertMaintenance, 
      id, 
      completed: false, 
      completedDate: null 
    };
    this.scheduledMaintenance.set(id, maintenance);
    return maintenance;
  }

  async completeMaintenance(id: number): Promise<ScheduledMaintenance | undefined> {
    const maintenance = this.scheduledMaintenance.get(id);
    if (!maintenance) return undefined;
    
    const completedMaintenance = { 
      ...maintenance, 
      completed: true, 
      completedDate: new Date() 
    };
    this.scheduledMaintenance.set(id, completedMaintenance);
    
    // Add to maintenance history
    await this.createMaintenanceRecord({
      machineId: maintenance.machineId,
      type: maintenance.type,
      description: maintenance.description,
      technician: maintenance.assignedTo,
      date: new Date(),
      duration: maintenance.estimatedDuration,
      partsReplaced: null,
      cost: null,
      notes: maintenance.notes
    });
    
    return completedMaintenance;
  }

  // Dashboard stats
  async getDashboardStats(): Promise<{
    totalEquipment: number;
    pendingMaintenance: number;
    criticalAlerts: number;
    uptime: number;
  }> {
    const machines = await this.getMachines();
    const pendingMaintenance = (await this.getScheduledMaintenance(false)).length;
    const criticalAlerts = (await this.getAlerts(false))
      .filter(alert => alert.type === 'critical').length;
    
    // Calculate average uptime as percentage of operational machines
    const operationalCount = machines.filter(m => m.status === 'operational').length;
    const uptime = machines.length > 0 
      ? (operationalCount / machines.length) * 100 
      : 0;
    
    return {
      totalEquipment: machines.length,
      pendingMaintenance,
      criticalAlerts,
      uptime
    };
  }

  // Helper to initialize sample data
  private initializeSampleData() {
    // Sample users
    this.createUser({ username: "admin", password: "admin123" });
    
    // Sample machines with different statuses
    const machines = [
      {
        name: "CNC Machine #103",
        type: "CNC",
        location: "Assembly Line A",
        installDate: new Date("2022-05-15"),
        status: "operational",
        totalHours: 3245,
        hoursSinceService: 230,
        targetServiceHours: 500,
        performance: 92,
        notes: "Last calibrated: Oct 12, 2023"
      },
      {
        name: "Injection Molder B24",
        type: "Injection Molder",
        location: "Molding Dept",
        installDate: new Date("2021-11-03"),
        status: "maintenance_due",
        totalHours: 5731,
        hoursSinceService: 492,
        targetServiceHours: 500,
        performance: 85,
        notes: "Full inspection needed"
      },
      {
        name: "Conveyor System #2",
        type: "Conveyor",
        location: "Packaging",
        installDate: new Date("2020-03-28"),
        status: "critical",
        totalHours: 12782,
        hoursSinceService: 862,
        targetServiceHours: 750,
        performance: 68,
        notes: "Motor overheating issues"
      },
      {
        name: "Robotic Arm D5",
        type: "Robotic Arm",
        location: "Assembly Line B",
        installDate: new Date("2023-01-10"),
        status: "operational",
        totalHours: 1892,
        hoursSinceService: 112,
        targetServiceHours: 1000,
        performance: 98,
        notes: "New model, high efficiency"
      },
      {
        name: "Furnace Unit #3",
        type: "Furnace",
        location: "Heat Treatment",
        installDate: new Date("2021-06-17"),
        status: "maintenance_due",
        totalHours: 4521,
        hoursSinceService: 472,
        targetServiceHours: 500,
        performance: 87,
        notes: "Heating elements need inspection"
      }
    ];
    
    // Add machines
    machines.forEach(machine => this.createMachine(machine as InsertMachine));
    
    // Add maintenance history
    this.createMaintenanceRecord({
      machineId: 1,
      type: "preventive",
      description: "Regular service",
      technician: "John Smith",
      date: new Date("2023-10-12"),
      duration: 120,
      partsReplaced: ["filter", "lubricant"],
      cost: 15000,
      notes: "Machine in good condition"
    });
    
    this.createMaintenanceRecord({
      machineId: 2,
      type: "corrective",
      description: "Full inspection",
      technician: "Maria Rodriguez",
      date: new Date("2023-09-03"),
      duration: 240,
      partsReplaced: ["sensor", "valve"],
      cost: 32000,
      notes: "Replaced faulty pressure sensor"
    });
    
    // Add alerts
    this.createAlert({
      machineId: 3,
      type: "critical",
      title: "Critical: Conveyor System #2",
      description: "Motor temperature exceeding threshold. Immediate maintenance required.",
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      resolved: false,
      priority: 1
    });
    
    this.createAlert({
      machineId: 2,
      type: "warning",
      title: "Maintenance Due: Injection Molder B24",
      description: "Scheduled maintenance due in 3 days. Planning required.",
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      resolved: false,
      priority: 2
    });
    
    this.createAlert({
      machineId: 5,
      type: "warning",
      title: "Maintenance Due: Furnace Unit #3",
      description: "Operational hours approaching maintenance threshold.",
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
      resolved: false,
      priority: 2
    });
    
    // Add scheduled maintenance
    this.createScheduledMaintenance({
      machineId: 2,
      type: "preventive",
      description: "Regular maintenance check",
      assignedTo: "Marcus Kim",
      scheduledDate: new Date("2023-11-15T09:00:00"),
      estimatedDuration: 120,
      notes: "Check hydraulic system"
    });
    
    this.createScheduledMaintenance({
      machineId: 3,
      type: "urgent",
      description: "Motor replacement",
      assignedTo: "Sarah Johnson",
      scheduledDate: new Date("2023-11-14T14:00:00"),
      estimatedDuration: 180,
      notes: "Full motor replacement required"
    });
    
    this.createScheduledMaintenance({
      machineId: 5,
      type: "regular",
      description: "Heating element inspection",
      assignedTo: "David Chen",
      scheduledDate: new Date("2023-11-18T10:30:00"),
      estimatedDuration: 90,
      notes: "Check all heating elements"
    });
  }
}

export const storage = new MemStorage();
